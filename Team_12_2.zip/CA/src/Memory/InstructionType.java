package Memory;

public enum InstructionType {
    Itype,
    Rtype;
}
